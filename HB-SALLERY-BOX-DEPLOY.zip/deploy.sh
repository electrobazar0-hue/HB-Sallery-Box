#!/bin/bash
# ========================================================
# HB Sallery Box - 1-Click cPanel Terminal Deployment Script
# ========================================================

set -e

echo "🚀 Starting Deployment for HB Sallery Box on cPanel..."

# 1. Check Node & NPM versions
echo "📦 Node Version: $(node -v 2>/dev/null || echo 'Not Found')"
echo "📦 NPM Version: $(npm -v 2>/dev/null || echo 'Not Found')"

# 2. Pull latest code if in a git repo
if [ -d ".git" ]; then
  echo "🔄 Pulling latest changes from Git repository..."
  git pull origin main || git pull origin master || echo "⚠️ Git pull skipped or not on tracked branch"
fi

# 3. Install production dependencies
echo "📥 Installing dependencies..."
npm install --legacy-peer-deps

# 4. Generate Prisma Client & Migrate DB
echo "🗄️ Setting up database..."
npx prisma generate
npx prisma db push --accept-data-loss

# 5. Build Next.js project
echo "🔨 Building Next.js application..."
npm run build

# 6. Start/Restart with PM2 (if available) or touch tmp/restart.txt for Passenger
if command -v pm2 &> /dev/null; then
  echo "⚡ Managing PM2 Process..."
  pm2 restart hb-salary-box || pm2 start ecosystem.config.js
  pm2 save
  echo "✅ PM2 Process is running!"
else
  # For cPanel Passenger Node.js app
  mkdir -p tmp
  touch tmp/restart.txt
  echo "✅ Passenger restart signaled (tmp/restart.txt)!"
fi

echo "🎉 Deployment completed successfully!"
echo "🌐 Your app is now live!"
